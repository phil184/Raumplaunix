package com.example.raumplaner;

import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class Databank {

    public static ArrayList<Room> rooms = new ArrayList<Room>();
    public static SharedPreferences sp;

    //Sucht in der Datenbank nach einem Raum und gibt alle Einzelheiten zurueck
    public static Room getRoomDetails(String name){
        if (!rooms.isEmpty())
            for (int i = 0; i < rooms.size(); i++)
                if (rooms.get(i).name.equals(name))
                    return rooms.get(i);
        addDefaultRoom(name);
        return rooms.get(rooms.size() - 1);
    }

    //Erstellt einen Platzhalterraum, falls nptwendig
    private static void addDefaultRoom(String name){
        rooms.add(new Room(name, 0, 0, 0, new ArrayList<>(), new ArrayList<>()));
    }

    //Entfernt einen bestimmten Raum
    public static void deleteRoom(String name){
        int id = -1;
        for (int i = 0; i < rooms.size(); i++)
            if (rooms.get(i).name.equals(name))
                id = i;
        rooms.remove(id);
        fileSave();
    }

    //Uebertraegt alle Raumdetails in die ArrayList
    public static Boolean saveRoom(String name, String tischplaetze, String stuehle,
                                   String nominalgroesse, ArrayList<String> sonderausstattung,
                                   ArrayList<String> mangel){
        StringBuilder str = new StringBuilder();
        str.append(name).append(tischplaetze).append(stuehle).append(nominalgroesse);
        for (int i = 0; i < sonderausstattung.size(); i++)
            str.append(sonderausstattung.get(i));
        for (int i = 0; i < mangel.size(); i++)
            str.append(mangel.get(i));
        if (str.toString().contains(",") || str.toString().contains("]"))
            return Boolean.FALSE;
        int id = -1;
        for (int i = 0; i < rooms.size(); i++)
            if (rooms.get(i).name.equals(name))
                id = i;
        if (id == -1)
            return Boolean.FALSE;
        rooms.set(id, new Room(name, Integer.parseInt(tischplaetze), Integer.parseInt(stuehle), Integer.parseInt(nominalgroesse), sonderausstattung, mangel));
        if (fileSave())
            return Boolean.TRUE;
        else
            return Boolean.FALSE;
    }

    //prueft, ob es einen nicht ausgefuellten Eintrag gibt
    public static Boolean checkEmpty(String name, String tischplaetze, String stuehle,
                                     String nominalgroesse, ArrayList<String> sonderausstattung,
                                     ArrayList<String> mangel) {
        if (name.isEmpty() || tischplaetze.isEmpty() || stuehle.isEmpty())
            return Boolean.TRUE;
        for (int i = 0; i < sonderausstattung.size(); i++)
            if (sonderausstattung.get(i).isEmpty())
                return Boolean.TRUE;
        for (int i = 0; i < mangel.size(); i++)
            if (mangel.get(i).isEmpty())
                return Boolean.TRUE;
        return Boolean.FALSE;
    }

    // Guides zum Speichern "Coding In Flow": https://youtu.be/fJEFZ6EOM9o
    //Uebertraegt die ArrayList in SharedPreferences
    public static Boolean fileSave(){
        SharedPreferences.Editor editor = sp.edit();
        String db = databankToString(rooms);
        if (db.equals("]"))
            return Boolean.FALSE;
        editor.putString("bank", db);
        editor.apply();
        return Boolean.TRUE;
    }

    //Uebertraegt SharedPreferences die ArrayList
    public static void fileLoad(){
        ArrayList<Room> load = stringToDatabank(sp.getString("bank", ""));
        rooms = stringToDatabank(sp.getString("bank", ""));
    }

    //Setzt SharedPreferences vollstaendig zurueck
    public static void fileDelete(){
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("bank", "");
        editor.apply();
    }

    //Konvertiert die ArrayList in String um
    public static String databankToString(ArrayList<Room> input){
        StringBuilder str = new StringBuilder();
        for (int r = 0; r < input.size(); r++){
            str.append(input.get(r).toString());
        }
        return str.toString();
    }

    //Konvertiert einen String zu einer ArrayList um
    private static ArrayList<Room> stringToDatabank(String input){
        int dividerLength = 2;
        char[] msg = input.toCharArray();
        System.out.println(msg);
        String ln = "";
        ArrayList<Room> bank = new ArrayList<Room>();
        int entry = 0;
        for (int c = 0; c < msg.length; c++){
            bank.add(new Room());

            //name
            ln = line(msg, c);
            bank.get(entry).name = ln;
            c += ln.length() + dividerLength;
            //tischplaetze
            ln = line(msg, c);
            bank.get(entry).tischplaetze = Integer.parseInt(ln);
            c += ln.length() + dividerLength;
            //stuehle
            ln = line(msg, c);
            bank.get(entry).stuehle = Integer.parseInt(ln);
            c += ln.length() + dividerLength;
            //nominalgroesse
            ln = line(msg, c);
            bank.get(entry).nominalgroesse = Integer.parseInt(ln);
            c += ln.length() + dividerLength;
            //sonderausstattung
            c++;
            while (msg[c] != ' ') {
                if (c >= msg.length)
                    return new ArrayList<>();
                ln = line(msg, c);
                if (ln.length() > 0)
                    bank.get(entry).sonderausstattung.add(ln);
                c += ln.length() + dividerLength;
            }
            c++;
            //mangel
            c++;
            while (msg[c] != ' ') {
                if (c >= msg.length)
                    return new ArrayList<>();
                ln = line(msg, c);
                if (ln.length() > 0)
                    bank.get(entry).mangel.add(ln);
                c += ln.length() + dividerLength;
            }

            System.out.println(bank.get(entry).toString());
            entry++;
        }
        return bank;
    }

    // Erstellt einen Teilstring aus einer gebundenen Nachricht mithilfe von Trennmarkern (",")
    private static String line(char[] msg, int start){
        StringBuilder str = new StringBuilder();
        int c = start;
        while (msg[c] != ',' && msg[c] != ']'){
            str.append(msg[c]);
            c++;
            if (c == msg.length)
                return "Fehler: Ende vom String: " + c + " " + msg.length;
        }
        return str.toString();
    }
}

class Room{
    String name;
    int tischplaetze;
    int stuehle;
    int nominalgroesse;
    ArrayList<String> sonderausstattung;
    ArrayList<String> mangel;

    public Room(String nm, int tp, int st, int gr, ArrayList<String> so, ArrayList<String> ma){
        name = nm;
        tischplaetze = tp;
        stuehle = st;
        nominalgroesse = gr;
        sonderausstattung = so;
        mangel = ma;
    }
    public Room(){
        name = "";
        tischplaetze = 0;
        stuehle = 0;
        nominalgroesse = 0;
        sonderausstattung = new ArrayList<String>();
        mangel = new ArrayList<String>();
    }

    @NonNull
    public String toString(){
        StringBuilder str = new StringBuilder();
        String divider = ", ";
        str.append(name).append(divider).append(tischplaetze)
                .append(divider).append(stuehle).append(divider).append(nominalgroesse)
                .append(divider).append(sonderausstattung.toString()).append(divider)
                .append(mangel).append(divider);
        return str.toString();
    }
}