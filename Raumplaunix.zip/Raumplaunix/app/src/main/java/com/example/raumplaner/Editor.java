package com.example.raumplaner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Editor extends AppCompatActivity {

    Button buttonHome, buttonSave, buttonDelete, buttonAddSonder, buttonAddMaengel;
    TextView tvRoomName;
    ListView lvSonder, lvMangel;
    EditText etTischplaetze, etStuehle, etNominalgroesse, etSonder, etMangel;
    //List-Array
    ArrayList<String> arraySonder, arrayMangel;
    ArrayAdapter<String> adapterSonder, adapterMangel;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        buttonHome = findViewById(R.id.buttonHome);
        buttonSave = findViewById(R.id.saveButton);
        buttonDelete = findViewById(R.id.deleteRoom);
        buttonAddSonder = findViewById(R.id.addbuttonSonder);
        buttonAddMaengel = findViewById(R.id.addbuttonMaengel);
        etTischplaetze = findViewById(R.id.editTextAnzahlTische);
        etStuehle = findViewById(R.id.editTextAnzahlStuehle);
        etNominalgroesse = findViewById(R.id.editTextRoomSize);
        etSonder = findViewById(R.id.addsonder);
        etMangel = findViewById(R.id.editTextMaengel);
        tvRoomName = findViewById(R.id.RoomID);
        lvSonder = findViewById(R.id.listSonder);
        lvMangel = findViewById(R.id.listMaengel);

        arraySonder = new ArrayList<String>();
        adapterSonder = new ArrayAdapter<String >(Editor.this, android.R.layout.simple_list_item_1, arraySonder);
        lvSonder.setAdapter(adapterSonder);

        arrayMangel = new ArrayList<String>();
        adapterMangel = new ArrayAdapter<String>(Editor.this, android.R.layout.simple_list_item_1, arrayMangel);
        lvMangel.setAdapter(adapterMangel);

        //Intent wird übergeben
        String raumnummer = getIntent().getStringExtra("name");
        Room raum = Databank.getRoomDetails(raumnummer);
        System.out.println(raum.toString());
        //Setze werte
        tvRoomName.setText(" Raum " + raumnummer);
        etTischplaetze.setText("" + raum.tischplaetze);
        etStuehle.setText("" + raum.stuehle);
        etNominalgroesse.setText("" + raum.nominalgroesse);
        //Setze Listen
        arraySonder.addAll(raum.sonderausstattung);
        adapterSonder.notifyDataSetChanged();
        arrayMangel.addAll(raum.mangel);
        adapterMangel.notifyDataSetChanged();

        //Definiere Button Clicks
        onClickHome();
        onClickAddSonder();
        onClickAddMangel();
        onClickSave(raumnummer);
        onClickDelete();
        longClickRemoveSonder();
        longClickRemoveMangel();
    }

    public void onClickHome(){
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });
    }

    public void onClickSave(String raumnummer){
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Databank.checkEmpty(raumnummer,
                        etTischplaetze.getText().toString(), etStuehle.getText().toString(),
                        etNominalgroesse.getText().toString(),
                        listviewToArray(lvSonder), listviewToArray(lvMangel)))
                    Toast.makeText(Editor.this, "Werte duerfen nicht leer sein",
                            Toast.LENGTH_SHORT).show();
                else {
                    if (Databank.saveRoom(raumnummer,
                            etTischplaetze.getText().toString(), etStuehle.getText().toString(),
                            etNominalgroesse.getText().toString(),
                            listviewToArray(lvSonder), listviewToArray(lvMangel))) {
                        Toast.makeText(Editor.this, "Gespeichert",
                                Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(Editor.this, "Speichern fehlgeschlagen. " +
                                "Zeichen \",\" und \"]\" duerfen nicht verwendet werden",
                                Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onClickDelete(){
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(Editor.this).setIcon(R.drawable.bin_full_256)
                        .setTitle("Bist du sicher?")
                        .setMessage("Der Raum wird geloescht")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String raumnummer = getIntent().getStringExtra("name");
                                Databank.deleteRoom(raumnummer);
                                Toast.makeText(Editor.this,"Raum: " + raumnummer +
                                        " geloescht",Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                            }
                        })
                        .setNegativeButton("No",null)
                        .show();
            }
        });
    }

    public void onClickAddSonder(){
        buttonAddSonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Text Inhalt von EditText ADD

                String result = etSonder.getText().toString();
                arraySonder.add(result);
                adapterSonder.notifyDataSetChanged();
            }
        });
    }

    public void onClickAddMangel(){
        buttonAddMaengel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = etMangel.getText().toString();
                arrayMangel.add(result);
                adapterMangel.notifyDataSetChanged();
            }
        });
    }


    public void longClickRemoveSonder(){
        lvSonder.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                final int position_delete = position;
                new AlertDialog.Builder(Editor.this).setIcon(R.drawable.bin_full_256)
                        .setTitle("Bist du sicher? ")
                        .setMessage("Das Element wird aus der Liste entfernt.")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                arraySonder.remove(position_delete);
                                adapterSonder.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("No",null)
                        .show();
                return true;
            }
        });
    }

    public void longClickRemoveMangel(){
        lvMangel.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                final int position_delete = position;
                new AlertDialog.Builder(Editor.this).setIcon(R.drawable.bin_full_256)
                        .setTitle("Bist du sicher? ")
                        .setMessage("Das Element wird aus der Liste entfernt.")
                        .setPositiveButton("Ja", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                arrayMangel.remove(position_delete);
                                adapterMangel.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Nein",null)
                        .show();
                return true;
            }
        });
    }

    //Wandelt die Eintraege einer ListView in eine ArrayList um
    ArrayList<String> listviewToArray(ListView listview){
        ArrayList<String> lst = new ArrayList<String>();
        for (int i = 0; i < listview.getCount(); i++)
            lst.add(listview.getItemAtPosition(i).toString());
        return lst;
    }
}