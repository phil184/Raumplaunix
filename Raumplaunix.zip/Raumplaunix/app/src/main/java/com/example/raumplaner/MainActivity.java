package com.example.raumplaner;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button buttonScan,buttonEdit, buttonDelete;
    EditText etRoomName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonEdit = findViewById(R.id.buttonEdit);
        buttonScan = findViewById(R.id.buttonScan);
        buttonDelete = findViewById(R.id.deleteDatenbank);
        etRoomName = findViewById(R.id.RoomIDFirst);
        etRoomName.addTextChangedListener(raumEingabe);

        Databank.sp = getSharedPreferences("rooms", Context.MODE_PRIVATE);
        //!!!Notfallsicherung!!!  -  falls die gespeicherte Datei Fehler enthaelt
        //Databank.fileDelete();
        Databank.fileLoad();

        onClickScanner();
        onClickEditor();
        onClickDelete();
    }

    public  void onClickScanner(){
        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Scanner_Activity.class));
            }
        });
    }

    public  void onClickEditor(){
        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String raumnummer = etRoomName.getText().toString();
                //temporaere Toasts fuer die Datenbank

                Intent intent = new Intent(MainActivity.this, Editor.class);
                intent.putExtra("name", raumnummer);
                startActivity(intent);
            }
        });
    }

    public void onClickDelete(){
        buttonDelete.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){

                new AlertDialog.Builder(MainActivity.this).setIcon(R.drawable.bin_full_256)
                        .setTitle("Bist du sicher?")
                        .setMessage("Die Datenbank wird gelöscht")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Databank.fileDelete();
                                Databank.fileLoad();
                                Toast.makeText(MainActivity.this,"Datenbank gelöscht",Toast.LENGTH_SHORT).show();

                            }
                        })
                        .setNegativeButton("No",null)
                        .show();


            }
        });
    }

    private TextWatcher raumEingabe = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String eingabe = etRoomName.getText().toString();
            buttonEdit.setEnabled(!eingabe.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}


